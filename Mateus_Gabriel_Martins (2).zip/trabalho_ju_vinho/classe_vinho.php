<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Cadastro de Vinho</title>
</head>
<body>
    <h1>Cadastro de Vinho</h1>
 
    <form method="POST">
        <label for="nome">Nome do Vinho:</label>
        <input type="text" id="nome" name="nome" required><br><br>
 
        <label for="tipo">Tipo de Vinho:</label>
        <input type="text" id="tipo" name="tipo" required><br><br>
 
        <label for="preco">Preço:</label>
        <input type="number" step="0.01" id="preco" name="preco" required><br><br>
 
        <label for="safra">Safra:</label>
        <input type="number" id="safra" name="safra" required><br><br>
 
        <input type="submit" name="cadastrar" value="Cadastrar">
    </form>
 
    <?php
    if (isset($_POST['cadastrar'])) {
        require_once 'Vinho.php';
        $nome = $_POST['nome'];
        $tipo = $_POST['tipo'];
        $preco = $_POST['preco'];
        $safra = $_POST['safra'];
 
        $vinho = new Vinho($nome, $tipo, $preco, $safra);
        echo "<h2>Informações do Vinho</h2>";
        echo "<p>" . $vinho->mostrarVinho() . "</p>";
 
        if ($vinho->verificarPreco()) {
            echo "<p>Produto em Oferta</p>";
        } else {
            echo "<p>Produto com preço normal!</p>";
        }
    }
    ?>
</body>
</html>